 
//document.write("Have a nice Day")
//window.print()
//var suna=window.prompt('Yaya sunanka/ki?')
//alert('Barka da zuwa '+ suna.toLowerCase() )

/* function validateForm() {
  var x = document.forms["myForm"]["name"].value;
  var y="Name"
  if (x == "") {
    alert(y+ " must be filled out");
    return false;
  }
} */
//window.print()

const name=document.getElementById("name")
const email=document.getElementById("email")
const phone=document.getElementById("phone")
const form=document.getElementById("form")
const error=document.getElementById('error')

form.addEventListener('submit', (e)=>{
  let message=[]
  if(name.value=== '' || name.value == null ){
    message.push("Shigar da sunanka/ki")
    document.myform.name.focus()
  }
  if(email.value=== '' || email.value==null){
    message.push('Shigar da email')
    document.myform.email.focus()
  }
  if (message.length>0){
    e.preventDefault()
    error.innerHTML=message.join(`,`)
  }
  
})

